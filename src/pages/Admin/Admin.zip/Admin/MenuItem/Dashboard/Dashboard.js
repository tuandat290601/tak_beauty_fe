import React from 'react';
import './Dashboard.scss';

export const Dashboard = () => {};
